# BinaryByte website

Files: index.html, style.css, script.js

Open in VS Code: File > Open Folder, choose this folder.
Preview: double-click index.html, or install the "Live Server" extension and click "Go Live".

Things to edit in index.html:
- Search for "[CEO Name]" and replace with the CEO's name.
- Search for "hello@binarybyte.dev" (3 places) and use your real email.
- Social links are in the section with class "social".
- Portfolio tiles are in the section with id "work".
- Colors and fonts are the variables at the top of style.css.
